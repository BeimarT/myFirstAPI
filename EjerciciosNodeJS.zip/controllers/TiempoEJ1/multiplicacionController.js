const status = {
    ok: 200,
    notFound: 404,
}

let mult2 = 2;

for (let i = 0; i < 12; i++) {
    console.log(`${n} * ${i} = ${n * i}`);
    
}

module.exports = {
    mult2: (req,send) => {

    },
    mult3: (req,send) => {

    },
    mult4: (req,send) => {

    },
    mult5: (req,send) => {

    },
    

}